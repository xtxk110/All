//获取影视网站数据
function GetWebUrl(){
	var data=[{name:"爱奇艺影视",url:"http://m.iqiyi.com/"},
                  {name:"腾讯视频",url:"https://m.v.qq.com/"},
                  {name:"优酷视频",url:"https://www.youku.com/"},
                  {name:"搜狐视频",url:"https://m.tv.sohu.com/"},
                  {name:"88影视",url:"https://m.88ys.cc/#?no"},
                  {name:"80影视",url:"https://m.80ys.net/#?no"},
                  {name:"其他影院",url:"http://www.tv3box.com/#?no"}
	         ];
	return data;
}
//http://www.gotopsports.com/Content/TV.apk  https://github.com/xtxk110/All/raw/master/TV.apk
var obj={
         ver:6.3,
	 url:"https://github.com/xtxk110/WebApp_TV/raw/master/TV/unpackage/release/TV.apk",
	 live:"http://633tv.com"
	};


