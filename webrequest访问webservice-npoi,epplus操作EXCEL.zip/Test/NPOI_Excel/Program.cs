﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System.IO;
using OfficeOpenXml;
using OfficeOpenXml.Style;

namespace NPOI_Excel
{
    class Program
    {
        static void Main(string[] args)
        {
            FileStream fileStream = new FileStream("F:\\template.xlsx", FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            //FileStream outStream = new FileStream("F:\\result.xlsx", FileMode.Create, FileAccess.Write);
            //XSSFWorkbook workbook = new XSSFWorkbook(fileStream);
            //ISheet sheet = workbook.GetSheetAt(0);
            //XSSFWorkbook outbook = new XSSFWorkbook();
            //ISheet outsheet = sheet.CopySheet("result", true);
            //outbook.Add(outsheet);
            

            //for (int i = 0; i <= outsheet.LastRowNum; i++)
            //{
            //    IRow row = outsheet.GetRow(i);
            //    for (int j = 0; j < row.LastCellNum; j++)
            //    {
            //        ICell cell = row.GetCell(j);

            //    }
            //}
            //outbook.Write(outStream);
            //outbook=null;
            //outStream.Close();
            //outStream.Dispose();
            //workbook = null;
            //fileStream.Dispose();

            /////////////////////////////
            ExcelPackage excel = new ExcelPackage(fileStream);
            ExcelWorksheet sheet = excel.Workbook.Worksheets[1];
            if (null != sheet.Dimension)
            {
                int startRow = sheet.Dimension.Start.Row;
                int strartColumn = sheet.Dimension.Start.Column;
                int endRow = sheet.Dimension.End.Row;
                int endColumn = sheet.Dimension.End.Column;
                for (int i = startRow; i <= endRow; i++)
                {
                    ExcelRow row = sheet.Row(i);
                    if(i==1)
                    {
                        row.Style.Font.Bold = true;
                        row.Style.Font.Size = 20;
                        row.Style.Font.Color.SetColor(System.Drawing.Color.Red);
                        row.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                        row.Height = 60;  
                        row.Style.Fill.PatternType = ExcelFillStyle.Solid;
                        row.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Gray);
                    }

                    for (int j = strartColumn; j <= endColumn; j++)
                    {
                        ExcelColumn column = sheet.Column(j);
                        var temp = sheet.GetValue(i, j);
                        bool flag = sheet.Cells[i, j].Merge;
                    }

                }
                for (int j = strartColumn; j <= endColumn; j++)
                {
                    sheet.Cells[endRow + 1, j].Value = (endRow + 1) + "-" + j;
                }
                    
            }
            excel.SaveAs(new FileInfo("F:\\result.xlsx"));
            excel.Dispose();
            fileStream.Close();

            Console.ReadKey();
        }
    }
}
