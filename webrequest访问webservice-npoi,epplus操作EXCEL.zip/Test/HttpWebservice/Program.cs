﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;
using System.Web;
using System.Xml;
using YDL.Utility;

namespace HttpWebservice
{
    class Program
    {
        static void Main(string[] args)
        {
            string url = "http://www.gotopsports.com:8068/service/dataservice.asmx";
            //string url = "http://192.168.0.254:8088/service/dataservice.asmx";
            string action = "ExcuteBll";
            string p1 = AESOperator.GetInstance().Encrypt("GetVideoList_210");
            string p2 = "{\"Token\": \"39a5fc021ceba6dbd8e7cc75ae0e66a7\",\"Version\": \"2.0.9\",\"Filter\": {\"PageIndex\": 1,\"IsRecommend\": \"false\",\"LiveType\": 1,\"PageSize\": 1000,\"LiveDate\": \"2019-07-15\"},\"IsMobile\": true, \"IsInnerTest\": true,\"IsEncrypt\": false} ";
            p2 = AESOperator.GetInstance().Encrypt(p2);
            string result = HttpPostWebService(url, action, p1, p2);
            Console.WriteLine(result);
            Console.ReadKey();
        }
        public static string HttpPostWebService(string url, string method, string p1,string p2)
        {
            string result = string.Empty;
            string param = string.Empty;
            byte[] bytes = null;

            Stream writer = null;
            HttpWebRequest request = null;
            HttpWebResponse response = null;

            param = HttpUtility.UrlEncode("serviceName") + "=" + HttpUtility.UrlEncode(p1,Encoding.UTF8) + "&" + HttpUtility.UrlEncode("request",Encoding.UTF8) + "=" + HttpUtility.UrlEncode(p2,Encoding.UTF8);
            //param = "serviceName" + "=" +p1+ "&" + "request"+ "=" + p2;
            bytes = Encoding.UTF8.GetBytes(param);

            request = (HttpWebRequest)WebRequest.Create(url + "/" + method);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = bytes.Length;
            request.Proxy = null;
            request.KeepAlive = false;
            ServicePointManager.DefaultConnectionLimit = 100;
            try
            {
                writer = request.GetRequestStream();        //获取用于写入请求数据的Stream对象
            }
            catch (Exception ex)
            {
                return "";
            }

            writer.Write(bytes, 0, bytes.Length);       //把参数数据写入请求数据流
            writer.Close();

            try
            {
                response = (HttpWebResponse)request.GetResponse();      //获得响应
            }
            catch (WebException ex)
            {
                return "";
            }

            #region 这种方式读取到的是一个返回的结果字符串
            //获取响应流
            Stream stream = response.GetResponseStream();
            //StreamReader reader = new StreamReader(stream, Encoding.UTF8);
            //result = reader.ReadToEnd();
            XmlTextReader Reader = new XmlTextReader(stream);
            
            Reader.MoveToContent();
            result = Reader.ReadInnerXml();
            #endregion
            response.Close();
            Reader.Close();
            stream.Dispose();
            stream.Close();
            request.Abort();

            return result;
        }
    }
}
