﻿using System;
namespace InTheHand.Net.Bluetooth.BlueSoleil
{
    internal interface IBluesoleilConnection
    {
        void CloseNetworkOrInternal();
    }
}