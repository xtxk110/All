using System;
using System.Text;
using NUnit.Framework;

namespace InTheHand.Net.Tests
{
    //[TestFixture]
    //public class MiscMostlyUnrelatedTesting
    //{
    //    [Test]
    //    public void TcpClient_AcceptsIpAddressToStringParameterConstructor()
    //    {
    //        System.Net.Sockets.TcpClient cli = new System.Net.Sockets.TcpClient();
    //        try {
    //            cli.Connect("127.0.0.1", 999);
    //        } catch (System.Net.Sockets.SocketException) {
    //        }
    //        System.Net.IPEndPoint ep = (System.Net.IPEndPoint)cli.Client.RemoteEndPoint;
    //        // This all works.  So showing that TcpClient.#ctor(String) accepts
    //        // an IP Address as well as a hostname.
    //    }
    //}
}


//--------------------------------------------------------------------
namespace InTheHand.Net.Tests.Mime
{

    //[TestFixture]
    //public class Misc
    //{
    //    //[Test]
    //    //public void CheckConstOnOne()
    //    //{
    //    //    Assert.AreEqual("image/gif", InTheHand.Net.Mime.MediaTypeNames.Image.Gif);
    //    //    // Attempt to change it!
    //    //    InTheHand.Net.Mime.MediaTypeNames.Image.Gif = "this should be read-only";
    //    //    // After fix to be 'const':
    //    //    //   Error: The left-hand side of an assignment must be a variable, property or indexer
    //    //    Assert.AreEqual("image/gif", InTheHand.Net.Mime.MediaTypeNames.Image.Gif);
    //    //}
    //
    //}//class

}
