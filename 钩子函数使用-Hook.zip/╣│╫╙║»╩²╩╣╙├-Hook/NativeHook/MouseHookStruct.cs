﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Drawing;

namespace NativeHook
{
    /// <summary>
    /// 鼠标钩子LParam参数对应的结构
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public class MouseHookStruct
    {
        /// <summary>
        /// Point(System.Drawing)结构对象，保存鼠标在屏幕上的x,y坐标
        /// </summary>
        public Point pt;
        /// <summary>
        /// 接收到鼠标消息的窗口的句柄
        /// </summary>
        public IntPtr hWnd;
        /// <summary>
        /// hit-test值，详细描述参见WM_NCHITTEST消息
        /// </summary>
        public int wHitTestCode;
        /// <summary>
        /// 指定与本消息联系的额外消息
        /// </summary>
        public int dwExtraInfo;

    }
}
