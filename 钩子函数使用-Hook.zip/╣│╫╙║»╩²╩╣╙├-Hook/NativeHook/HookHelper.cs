﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace NativeHook
{
    public class HookHelper
    {
        #region WIN32 API
        [DllImport("user32.dll")]
        static extern IntPtr SetWindowsHookEx(HookType hook, HookProc callback, IntPtr hMod, uint dwThreadId);

        [DllImport("user32.dll")]
        static extern bool UnhookWindowsHookEx(IntPtr hhk);

        [DllImport("user32.dll")]
        static extern int CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll")]
        static extern short GetKeyState(VirtualKeys nVirtKey);
        [DllImport("kernel32.dll")]
        public static extern IntPtr GetModuleHandle(String lpModuleName)
        #endregion

        //SetWindowsHookEx安装钩子时调用。
        public delegate int HookProc(int nCode, int wParam, IntPtr lParam);
        //用于获取消息
        private static HookProc MouseHookProcedure;
        private static HookProc KeyboardHookProcedure;

        int hMouseHook = 0;int hKeyboardHook = 0;

        #region Events

        /// <summary>
        /// 当用户移动鼠标，按下任意鼠标按钮或滚动的车轮
        /// </summary>
        public event MouseEventHandler OnMouseActivity;
        /// <summary>
        /// 发生时，用户按下一个键
        /// </summary>
        public event KeyEventHandler KeyDown;
        /// <summary>
        /// 当用户按下并释放
        /// </summary>
        public event KeyPressEventHandler KeyPress;
        /// <summary>
        /// 当用户释放的关键
        /// </summary>
        public event KeyEventHandler KeyUp;

        #endregion

        public void Start(bool InstallMouseHook, bool InstallKeyboardHook)
        {
            //定义鼠标钩子函数
            if (hMouseHook == 0 && InstallMouseHook)
            {
                //关联鼠标事件
                MouseHookProcedure = new HookProc(MouseHookProc);
                //IntPtr ha=Marshal.GetHINSTANCE(Assembly.GetExecutingAssembly().GetModules()[0]);
                IntPtr ha = GetModuleHandle(Process.GetCurrentProcess().MainModule.ModuleName);
                //注册为全局钩子，后面会讲解
                hMouseHook = (int)SetWindowsHookEx(HookType.WH_MOUSE_LL, MouseHookProcedure, ha, 0);
                //hMouseHook = SetWindowsHookEx(WH_MOUSE, MouseHookProcedure,IntPtr.Zero, 0);

                if (hMouseHook == 0)
                {
                    int errorCode = Marshal.GetLastWin32Error();
                    Stop(true, false, false);
                    throw new Win32Exception(errorCode);
                    //throw new Exception(errorCode.ToString());
                }
            }
            if (hKeyboardHook == 0 && InstallKeyboardHook)
            {
                KeyboardHookProcedure = new HookProc(KeyboardHookProc);
                //IntPtr ha = Marshal.GetHINSTANCE(Assembly.GetExecutingAssembly().GetModules()[0]);
                IntPtr ha = GetModuleHandle(Process.GetCurrentProcess().MainModule.ModuleName);
                hKeyboardHook = (int)SetWindowsHookEx(HookType.WH_KEYBOARD_LL, KeyboardHookProcedure, ha, 0);
                //hKeyboardHook = SetWindowsHookEx(WH_KEYBOARD, KeyboardHookProcedure,IntPtr.Zero, 0);
                if (hKeyboardHook == 0)
                {
                    int errorCode = Marshal.GetLastWin32Error();
                    Stop(false, true, false);
                    throw new Win32Exception(errorCode);
                    //throw new Exception(errorCode.ToString());
                }
            }
        }
        private int MouseHookProc(int nCode, int wParam, IntPtr lParam)
        {
            if ((nCode >= 0) && (OnMouseActivity != null))
            {
                MouseLLHookStruct mouseHookStruct = (MouseLLHookStruct)Marshal.PtrToStructure(lParam, typeof(MouseLLHookStruct));

                MouseButtons button = MouseButtons.None;
                short mouseDelta = 0;
                switch (wParam)
                {
                    case WM_LBUTTONDOWN:
                        //case WM_LBUTTONUP: 
                        //case WM_LBUTTONDBLCLK: 
                        button = MouseButtons.Left;
                        break;
                    case WM_RBUTTONDOWN:
                        //case WM_RBUTTONUP: 
                        //case WM_RBUTTONDBLCLK: 
                        button = MouseButtons.Right;
                        break;
                    case WM_MOUSEWHEEL:
                        //如果消息是WM_MOUSEWHEEL，高阶字的mouseData成员车轮三角洲。
                        //点击一个车轮被定义为，这是120 WHEEL_DELTA
                        //(value >> 16) & 0xffff; retrieves the high-order word from the given 32-bit value
                        mouseDelta = (short)((mouseHookStruct.mouseData >> 16) & 0xffff);
                        //TODO: X BUTTONS (I havent them so was unable to test)
                        //如果消息是WM_XBUTTONUP WM_XBUTTONDOWN，WM_XBUTTONDBLCLK，WM_NCXBUTTONDOWN，WM_NCXBUTTONUP
                        //或WM_NCXBUTTONDBLCLK的，高阶字指定X键被按下或释放，
                        //低位字被保留。这个值可以是以下值中的一个或多个。
                        //否则，mouseData还没有使用。
                        break;
                }
                int clickCount = 0;
                if (button != MouseButtons.None)
                    if (wParam == WM_LBUTTONDBLCLK || wParam == WM_RBUTTONDBLCLK)
                        clickCount = 2;
                    else clickCount = 1;

                MouseEventArgs e = new MouseEventArgs(button, clickCount, mouseHookStruct.pt.x, mouseHookStruct.pt.y, mouseDelta);
                OnMouseActivity(this, e);
            }
            return CallNextHookEx(hMouseHook, nCode, wParam, lParam);
        }
        //键盘事件响应函数，在注册后，就可以在这函数添加响应
        private int KeyboardHookProc(int nCode, Int32 wParam, IntPtr lParam)
        {
            try
            {
                bool handled = false;
                if ((nCode >= 0) && (KeyDown != null || KeyUp != null || KeyPress != null))
                {
                    KeyboardHookStruct MyKeyboardHookStruct = (KeyboardHookStruct)
                        Marshal.PtrToStructure(lParam, typeof(KeyboardHookStruct));
                    if (KeyDown != null && (wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN))
                    {
                        Keys keyData = (Keys)MyKeyboardHookStruct.vkCode;
                        KeyEventArgs e = new KeyEventArgs(keyData);
                        KeyDown(this, e);
                        handled = handled || e.Handled;
                    }
                    if (KeyPress != null && wParam == WM_KEYDOWN)
                    {
                        bool isDownShift = ((GetKeyState(VK_SHIFT) & 0x80) == 0x80 ? true : false);
                        bool isDownCapslock = (GetKeyState(VK_CAPITAL) != 0 ? true : false);

                        byte[] keyState = new byte[256];
                        GetKeyboardState(keyState);
                        byte[] inBuffer = new byte[2];
                        if (ToAscii(MyKeyboardHookStruct.vkCode, MyKeyboardHookStruct.scanCode, keyState, inBuffer, MyKeyboardHookStruct.flags) == 1)
                        {
                            char key = (char)inBuffer[0];
                            if ((isDownCapslock ^ isDownShift) && Char.IsLetter(key))
                            {
                                key = Char.ToUpper(key);
                            }
                            KeyPressEventArgs e = new KeyPressEventArgs(key);
                            KeyPress(this, e);
                            handled = handled || e.Handled;
                        }
                    }
                    if (KeyUp != null && (wParam == WM_KEYUP || wParam == WM_SYSKEYUP))
                    {
                        Keys keyData = (Keys)MyKeyboardHookStruct.vkCode;
                        KeyEventArgs e = new KeyEventArgs(keyData);
                        KeyUp(this, e);
                        handled = handled || e.Handled;
                    }

                }
                if (handled)
                    return 1;
                else
                    return 0;//CallNextHookEx(hKeyboardHook, nCode, wParam, lParam);
            }
            catch (Exception ex)
            {
                return -1;
            }
        }

        public void Stop()
        {
            this.Stop(true, true, true);
        }
        //钩子卸载
        public void Stop(bool UninstallMouseHook, bool UninstallKeyboardHook, bool ThrowExceptions)
        {
            if (hMouseHook != 0 && UninstallMouseHook)
            {
                int retMouse = UnhookWindowsHookEx(hMouseHook);
                hMouseHook = 0;
                if (retMouse == 0 && ThrowExceptions)
                {
                    int errorCode = Marshal.GetLastWin32Error();
                    throw new Win32Exception(errorCode);
                }
            }
            if (hKeyboardHook != 0 && UninstallKeyboardHook)
            {
                int retKeyboard = UnhookWindowsHookEx(hKeyboardHook);
                hKeyboardHook = 0;
                if (retKeyboard == 0 && ThrowExceptions)
                {
                    int errorCode = Marshal.GetLastWin32Error();
                    throw new Win32Exception(errorCode);
                }
            }
        }
    }
}
