﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Management;

namespace Management
{
    class Program
    {
        static void Main(string[] args)
        {
            WmiQuery("Win32_PhysicalMemory");

            while(true){
                Console.Write("请输入正确的WMI空间名称类,以回车结束:");
                string read = Console.ReadLine().Trim();
                if (read.ToUpper() == "Q")
                    return;
                Console.Clear();
                try
                {
                    WmiQuery(read);
                }catch(Exception e)
                {
                    Console.WriteLine(e.Message + ";请重新输入!");
                }
            }
        }
        /// <summary>
        /// WMI名称空间
        /// </summary>
        /// <param name="wmiName"></param>
        static void WmiQuery(string wmiName)
        {
            ManagementObjectSearcher searcher = new ManagementObjectSearcher("select * from "+wmiName);
            foreach (ManagementObject item in searcher.Get())
            {
                Console.WriteLine(item["Name"]);
                Console.WriteLine("PropertyData对象数量:" + item.Properties.Count);
                foreach (PropertyData item1 in item.Properties)
                {
                    Console.WriteLine("\t属性名称:" + item1.Name + "->属性值:" + item1.Value);
                    //Console.WriteLine("\t属性上的限定符集数量:"+item1.Qualifiers.Count);
                    //foreach(QualifierData item2 in item1.Qualifiers)
                    //{
                    //    Console.WriteLine("\t\t限定符名称:" + item2.Name+ "->限定符值:" + item2.Value);
                    //}
                }
            }
        }
    }
}
