﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ReceiveSendBall;
using System.Configuration;

namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            LoopData loopData = new LoopData
            {
                Team1Id = "B6438180-78E3-4A53-A569-3BEB30C0BFD9",
                Team2Id = "7095E3E0-2B0B-4780-A7C4-5555A61457F7",
                LoopId = "bad1ee73-985a-49bd-acad-a5d000ed10b2",
                MapId = "0139ddd3-68a3-449d-990c-a5d000f69f51",
                LoopCount = 5,
                IsTeam = true,
                OrderNo = 1,
                DefaultRecUserId = "001012",
                DefaultSendUserId = "001003",
                DicUser = new Dictionary<string, User>()
            };
            loopData.DicUser.Add("001012", new User { TeamId = "B6438180-78E3-4A53-A569-3BEB30C0BFD9", UserId = "001012", UserName = "管理员12" });
            loopData.DicUser.Add("001040", new User { TeamId = "B6438180-78E3-4A53-A569-3BEB30C0BFD9", UserId = "001040", UserName = "管理员40" });
            loopData.DicUser.Add("001003", new User { TeamId = "7095E3E0-2B0B-4780-A7C4-5555A61457F7", UserId = "001003", UserName = "管理员3" });
            loopData.DicUser.Add("001022", new User { TeamId = "7095E3E0-2B0B-4780-A7C4-5555A61457F7", UserId = "001022", UserName = "管理员22" });

            Helper.SetDefaultBall(loopData.DefaultRecUserId, loopData.DefaultSendUserId, loopData);
            Show(loopData);

            Console.WriteLine("输入Q或q退出程序......");
            Console.WriteLine("=============================================");
            while (true)
            {
                try
                {
                    Console.Write("请输入队伍1得分,按回车结束:");
                    string input = Console.ReadLine();
                    if (input.ToLower() == "q")
                        break;
                    loopData.SmallScore1 += int.Parse(input);

                    Console.Write("请输入队伍2得分,按回车结束:");
                    input = Console.ReadLine();
                    if (input.ToLower() == "q")
                        break;
                    loopData.SmallScore2 += int.Parse(input);

                    Helper.SetBall(loopData);
                    Show(loopData);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    Console.WriteLine("*******************************************");
                    continue;
                }
            }
            //while (true)
            //{
            //    Console.WriteLine(ConfigurationManager.AppSettings["test"]);
            //    System.Threading.Thread.Sleep(5000);
            //}

        }
        static void Show(LoopData loopData)
        {
            foreach (var item in loopData.DicUser)
                Console.WriteLine("姓名:{0}->发球:{1}->接球:{2}->队伍ID:{3}", item.Value.UserName, item.Value.IsSendBall, item.Value.IsReceiveBall, item.Value.TeamId);
        }
    }
}
