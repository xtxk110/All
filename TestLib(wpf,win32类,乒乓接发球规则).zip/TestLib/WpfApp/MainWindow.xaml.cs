﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;

namespace WpfApp
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        ObservableCollection<Test> GridData = new ObservableCollection<Test>();
        public MainWindow()
        {
            InitializeComponent();
            this.dg.LoadingRow += Dg_LoadingRow;
            //this.dg.GotFocus += Dg_GotFocus;
            this.dg.MouseDoubleClick += Dg_MouseDoubleClick;
            this.dg.RowDetailsVisibilityChanged += Dg_RowDetailsVisibilityChanged;
            
            for (int i=0;i<50;i++)
                GridData.Add(new Test { Name = "张三"+i, IsSelected = i%2==0?true:false, Remark = "备注内容00"+i });
        }

        private void Dg_RowDetailsVisibilityChanged(object sender, DataGridRowDetailsEventArgs e)
        {
            //throw new NotImplementedException();
        }

        private void Dg_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            DataGridRow row = this.dg.ItemContainerGenerator.ContainerFromIndex(this.dg.SelectedIndex) as DataGridRow;
            if (row != null)
            {
                if (row.DetailsVisibility == Visibility.Visible)
                    row.DetailsVisibility = Visibility.Collapsed;
                else if (row.DetailsVisibility == Visibility.Collapsed)
                    row.DetailsVisibility = Visibility.Visible;
            }
            var obj = this.dg.SelectedItem as DataGridRow;
            

        }

        private void Dg_GotFocus(object sender, RoutedEventArgs e)
        {
            DataGridCell cell = e.OriginalSource as DataGridCell;
            if(cell != null)
            {
                CheckBox check = cell.Content as CheckBox;
                if (check != null)
                    check.IsChecked = !check.IsChecked;
            }
           
            Console.WriteLine(e.OriginalSource.GetType());
        }

        private void TextBox_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.Cursor = Cursors.Hand;
            TextBox text = sender as TextBox;
            text.AllowDrop = false;
            DragDrop.DoDragDrop(text, text.Text, DragDropEffects.Move);
        }

        private void tb_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Text))
            {
                e.Effects = DragDropEffects.Move;
            }
            else
                e.Effects = DragDropEffects.None;
        }

        private void tb_Drop(object sender, DragEventArgs e)
        {
            var test = e.OriginalSource;
            var test1 = e.Source;
            TextBlock textBlock = sender as TextBlock;
            textBlock.Text = e.Data.GetData(DataFormats.Text) as string;
            //tbox.Text = "";
            tbox.Visibility = Visibility.Hidden;
            e.Handled = true;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.dg.ItemsSource = GridData;
            this.lv.ItemsSource = GridData;
            GetSsid();
        }

        private void Dg_LoadingRow(object sender, DataGridRowEventArgs e)
        {
            e.Row.Header = e.Row.GetIndex() + 1;
        }

        private void CheckBox_Click(object sender, RoutedEventArgs e)
        {
            Console.WriteLine(e.OriginalSource.GetType());
        }

        private void dg_ScrollChanged(object sender, ScrollChangedEventArgs e)
        {
            double t1 = e.ExtentHeight;
            double t2 = e.ViewportHeight;
            double t3 = e.VerticalOffset;
            double t4 = e.VerticalChange;
        }

        private void lv_ScrollChanged(object sender, ScrollChangedEventArgs e)
        {

        }
        private void GetSsid()
        {
            Process process = new Process();
            ProcessStartInfo startInfo = new ProcessStartInfo { CreateNoWindow = true, UseShellExecute = false, RedirectStandardError = true, RedirectStandardInput = true, RedirectStandardOutput = true };
            startInfo.FileName = "cmd.exe ";
            startInfo.Arguments = "";
            process.StartInfo = startInfo;
            process.Start();
            process.StandardInput.WriteLine("netsh wlan show networks mode = bssid & EXIT");
            this.ssid.Text = process.StandardOutput.ReadToEnd();
            process.WaitForExit();
            process.Close();
        }
    }
    public class Test: INotifyPropertyChanged
    {
        string _name;
        public string Name { get { return _name; } set { _name = value; if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs("Name")); } }

        bool _isSelected;
        public bool IsSelected { get { return _isSelected; } set { _isSelected = value; if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs("IsSelected")); } }

        string _remark;
        public string Remark { get { return _remark; } set { _remark = value; if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs("Remark")); } }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
