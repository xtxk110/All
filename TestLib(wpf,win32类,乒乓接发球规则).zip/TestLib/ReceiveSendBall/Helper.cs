﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ReceiveSendBall
{
    public class Helper
    {
        /// <summary>
        /// 设置(单打)双打接发球
        /// </summary>
        /// <param name="loopData">LoopData</param>
        public static void SetBall(LoopData loopData,bool isDouble=true)
        {
            int step = 2;//10:10之前发2球,比分之后,发1球
            int max = loopData.SmallScore1 > loopData.SmallScore2 ? loopData.SmallScore1 : loopData.SmallScore2;//获取最大的小局得分
            int diff = Math.Abs(loopData.SmallScore1 - loopData.SmallScore2);
            if (max >= 11 && diff >= 2)
                return;

            if (loopData.SmallScore1 >= 10 && loopData.SmallScore2 >= 10)//10:10之前发2球,比分之后,发1球
                step = 1;

            //局胜局(最后一局,奇数局)
            if (loopData.LoopCount == loopData.OrderNo)
            {
                if (max == 5)//任何一队先得5分,换边,接发球按偶数局设置
                {
                    loopData.OrderNo -= 1;
                    SetDefaultBall(loopData.DefaultRecUserId, loopData.DefaultSendUserId, loopData);//换边设置
                    loopData.OrderNo += 1;
                    return;
                }
            }

            if (loopData.Ball >= step)//换发球
            {
                loopData.Ball = 1;

                User oldRec = loopData.DicUser.Where(item => item.Value.IsReceiveBall).FirstOrDefault().Value;//原来接球的队员
                User oldSend = loopData.DicUser.Where(item => item.Value.IsSendBall).FirstOrDefault().Value;//原来发球队员
                if (!isDouble)//单打时
                {
                    oldRec.IsReceiveBall = false;
                    oldRec.IsSendBall = true;
                    oldSend.IsReceiveBall = true;
                    oldSend.IsSendBall = false;
                    return;
                }
                //双打
                User free= loopData.DicUser.Where(item => item.Value.TeamId == oldRec.TeamId && item.Value.UserId != oldRec.UserId).FirstOrDefault().Value;//空闲
                User newRec = loopData.DicUser.Where(item => item.Value.TeamId == oldSend.TeamId && item.Value.UserId != oldSend.UserId).FirstOrDefault().Value;//新接球队员
                
                //接发球状态先归置为false
                SetFalseBall(loopData);
                //根据得出的 User 统一设置接发球标志:原来接球队员变为发球队员,对方空闲人员为接球队员
                oldRec.IsSendBall = true;newRec.IsReceiveBall = true;
            }
            else
                loopData.Ball += 1;
           
        }
        /// <summary>
        /// 根据比分设置接发球顺序
        /// </summary>
        /// <param name="loopData">LoopData</param>
        /// <param name="isDouble">是否是双打</param>
        public static void SetBallByScore(LoopData loopData, bool isDouble = true)
        {
            int step = 2;//10:10之前发2球,比分之后,发1球
            int max = loopData.SmallScore1 > loopData.SmallScore2 ? loopData.SmallScore1 : loopData.SmallScore2;//获取最大的小局得分
            int diff = Math.Abs(loopData.SmallScore1 - loopData.SmallScore2);
            if (max >= 11 && diff >= 2)
                return;

            if (loopData.SmallScore1 > 10 && loopData.SmallScore2 > 10)//10:10之前发2球,比分之后,发1球
                step = 1;

            //局胜局(最后一局,奇数局)
            if (loopData.LoopCount == loopData.OrderNo)
            {
                if (max == 5)//任何一队先得5分,换边,接发球按偶数局设置
                {
                    loopData.ChangeScore = loopData.SmallScore1 + loopData.SmallScore2;
                    loopData.OrderNo -= 1;
                    SetDefaultBall(loopData.DefaultRecUserId, loopData.DefaultSendUserId, loopData);//换边设置
                    loopData.OrderNo += 1;
                    return;
                }
            }

            //换发球计算(两队得分和+两队罚分和-两队让分和-决胜局5分时两队得分和)
            int sum = (loopData.SmallScore1 + loopData.SmallScore2) + (loopData.DeductionScore1 + loopData.DeductionScore2) - (loopData.AddtionalScore1 + loopData.AddtionalScore2)-loopData.ChangeScore;

            User oldRec = loopData.DicUser.Where(item => item.Value.IsReceiveBall).FirstOrDefault().Value;//原来接球的队员
            User oldSend = loopData.DicUser.Where(item => item.Value.IsSendBall).FirstOrDefault().Value;//原来发球队员
            User defaultRec = loopData.DicUser[loopData.DefaultRecUserId];//每局开始默认的接球队员
            User defaultSend = loopData.DicUser[loopData.DefaultSendUserId];//每局开始默认的发球队员
            if (isDouble)//双打
            {
                //接球方同队队员
                User other1 = loopData.DicUser.Where(item => item.Value.TeamId == defaultRec.TeamId && item.Value.UserId != defaultRec.UserId).FirstOrDefault().Value;
                //发球方同队队员
                User other2 = loopData.DicUser.Where(item => item.Value.TeamId == defaultSend.TeamId && item.Value.UserId != defaultSend.UserId).FirstOrDefault().Value;
                //接发球状态先归置为false
                SetFalseBall(loopData);
                //根据比分设置双方队员接发球标志
                switch (sum % 8)
                {
                    case 0:
                        if (step == 2)
                        {
                            defaultSend.IsSendBall = true;
                            defaultRec.IsReceiveBall = true;
                        }
                        else if (step == 1)
                            goto case 4;
                        break;
                    case 1:
                        if (step == 2)
                            goto case 0;
                        else if (step == 1)
                            goto case 5;
                        break;
                    case 2:
                        if (step == 2)
                        {
                            defaultRec.IsSendBall = true;
                            other2.IsReceiveBall = true;
                        }
                        else if (step == 1)
                            goto case 6;

                        break;
                    case 3:
                        if (step == 2)
                            goto case 2;
                        if (step == 1)
                            goto case 7;
                        break;
                    case 4://10:10时,正好是换发球边界
                        other2.IsSendBall = true;
                        other1.IsReceiveBall = true;
                        break;
                    case 5:
                        if (step == 2)
                            goto case 4;
                        else if (step == 1)
                        {
                            other1.IsSendBall = true;
                            defaultSend.IsReceiveBall = true;
                        }
                        break;
                    case 6:
                        if (step == 2)
                        {
                            other1.IsSendBall = true;
                            defaultSend.IsReceiveBall = true;
                        }
                        else if (step == 1)
                        {
                            defaultSend.IsSendBall = true;
                            defaultRec.IsReceiveBall = true;
                        }
                        break;
                    case 7:
                        if (step == 2)
                            goto case 6;
                        else if (step == 1)
                        {
                            defaultRec.IsSendBall = true;
                            other2.IsReceiveBall = true;
                        }
                        break;
                }
            }
            else//单打
            {
                switch (sum % 4)
                {
                    case 0://10:10时,正好是换发球边界

                        defaultSend.IsSendBall = true;
                        defaultRec.IsReceiveBall = true;
                        break;
                    case 1:
                        if (step == 2)
                            goto case 0;
                        else if (step == 1)
                        {
                            defaultRec.IsSendBall = true;
                            defaultSend.IsReceiveBall = true;
                        }
                        break;
                    case 2:
                        if (step == 2)
                        {
                            defaultRec.IsSendBall = true;
                            defaultSend.IsReceiveBall = true;
                        }
                        else if (step == 1)
                            goto case 0;

                        break;
                    case 3:
                        if (step == 2)
                            goto case 2;
                        if (step == 1)
                            goto case 1;
                        break;
                }
            }
        }
        /// <summary>
        /// 设置接发球队员(每局开始必须先调用)
        /// </summary>
        /// <param name="recUserId">默认接球队员ID</param>
        /// <param name="sendUserId">默认发球队员ID</param>
        /// <param name="loopData">LoopData</param>
        public static void SetDefaultBall(string recUserId,string sendUserId, LoopData loopData)
        {
            if (loopData.OrderNo == 0)
                return;
            loopData.Ball = 1;//设置默认发球数为1
            loopData.DeductionScore1 = 0;
            loopData.DeductionScore2 = 0;
            SetFalseBall(loopData);//设置当前小局对阵人员接发球为false
            if (loopData.OrderNo % 2 == 0)//偶数局与默认首局设置的相反
            {
                loopData.DicUser[recUserId].IsSendBall = true;
                loopData.DicUser[sendUserId].IsReceiveBall = true;
            }
            else
            {
                loopData.DicUser[recUserId].IsReceiveBall = true;
                loopData.DicUser[sendUserId].IsSendBall = true;
            }
        }
        /// <summary>
        /// 设置当前小局对阵人员接发球为false
        /// </summary>
        /// <param name="loopData">LoopData</param>
        static void SetFalseBall(LoopData loopData)
        {
            foreach (var item in loopData.DicUser)
            {
                item.Value.IsReceiveBall = false;
                item.Value.IsSendBall = false;
            }
        }
    }
}
