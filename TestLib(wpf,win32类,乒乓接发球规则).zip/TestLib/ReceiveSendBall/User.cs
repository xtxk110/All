﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ReceiveSendBall
{
    public class User
    {
        /// <summary>
        /// 队员ID
        /// </summary>
        public string UserId { get; set; }
        /// <summary>
        /// 队员姓名
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// 队伍ID
        /// </summary>
        public string TeamId { get; set; }
        /// <summary>
        /// 红牌次数
        /// </summary>
        public int RedCard { get; set; }
        /// <summary>
        /// 黄牌次数
        /// </summary>
        public int YellowCard { get; set; }
        /// <summary>
        /// 罚分
        /// </summary>
        public int DeductionScore { get; set; }
        /// <summary>
        /// 是否发球
        /// </summary>
        public bool IsSendBall { get; set; }
        /// <summary>
        /// 是否接球
        /// </summary>
        public bool IsReceiveBall { get; set; }
        
    }
}
