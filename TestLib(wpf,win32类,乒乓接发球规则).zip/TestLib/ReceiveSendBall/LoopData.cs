﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ReceiveSendBall
{
    public class LoopData
    {
        /// <summary>
        /// 队伍1ID
        /// </summary>
        public string Team1Id { get; set; }
        /// <summary>
        /// 队伍2ID
        /// </summary>
        public string Team2Id { get; set; }
        /// <summary>
        /// 队伍1名称
        /// </summary>
        public string Team1Name { get; set; }
        /// <summary>
        /// 队伍2名称
        /// </summary>
        public string Team2Name { get; set; }
        /// <summary>
        /// 队伍1小局对阵得分
        /// </summary>
        public int SmallScore1 { get; set; }
        /// <summary>
        /// 队伍2小局对阵得分
        /// </summary>
        public int SmallScore2 { get; set; }
        /// <summary>
        /// 队伍1得分
        /// </summary>
        public int TeamScore1 { get; set; }
        /// <summary>
        /// 队伍2得分
        /// </summary>
        public int TeamScore2 { get; set; }
        /// <summary>
        /// 团体对阵时,队伍1 Map得分
        /// </summary>
        public int MapScore1 { get; set; }
        /// <summary>
        /// 团体对阵时,队伍2 Map得分
        /// </summary>
        public int MapScore2 { get; set; }
        /// <summary>
        /// 小局对阵序号
        /// </summary>
        public int OrderNo { get; set; }
        /// <summary>
        /// 小局对阵总局数
        /// </summary>
        public int LoopCount { get; set; }
        /// <summary>
        /// 是否是团体对阵
        /// </summary>
        public bool IsTeam { get; set; }
        /// <summary>
        /// 团体对阵时MapId
        /// </summary>
        public string MapId { get; set; }
        /// <summary>
        /// LOOP对阵ID
        /// </summary>
        public string LoopId { get; set; }
        /// <summary>
        /// 小局对阵人员字典key:队员ID,value:User
        /// </summary>
        public Dictionary<string,User> DicUser { get; set; }
        /// <summary>
        /// 当前发球(接球)总数(换发球前),比如:2,或1
        /// </summary>
        public int Ball { get; set; }
        /// <summary>
        /// 设置的默认接球队员ID
        /// </summary>
        public string DefaultRecUserId { get; set; }
        /// <summary>
        /// 设置的默认发球队员ID
        /// </summary>
        public string DefaultSendUserId { get; set; }
        /// <summary>
        /// 小局对阵,队伍1获得的让分(每局开始都要初始化)
        /// </summary>
        public int AddtionalScore1 { get; set; }
        /// <summary>
        /// 小局对阵,队伍2获得的让分(每局开始都要初始化)
        /// </summary>
        public int AddtionalScore2 { get; set; }
        /// <summary>
        /// 小局对阵,队伍1扣除的分(每局开始都要初始化为0)
        /// </summary>
        public int DeductionScore1 { get; set; }
        /// <summary>
        /// 小局对阵,队伍2扣除的分(每局开始都要初始化为0)
        /// </summary>
        public int DeductionScore2 { get; set; }
        /// <summary>
        /// 决胜局,任何一方到达5分时,双方小局得分和
        /// </summary>
        public int ChangeScore { get; set; }
    }
}
