﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Timers;
using System.Configuration;
using System.Deployment;
using System.Deployment.Application;

namespace WxPayOperator
{
    class Program
    {
        static Timer timer;
        static void Main(string[] args)
        {
            Do();
            timer = new Timer(double.Parse(ConfigurationManager.AppSettings["elapsedTime"]));
            timer.Elapsed += Timer_Elapsed;
            timer.AutoReset = true;
            timer.Enabled = true;
            
            Console.ReadKey();
        }

        private static void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            timer.Enabled = false;
            ConfigurationManager.RefreshSection("appSettings");
            timer.Interval = double.Parse(ConfigurationManager.AppSettings["elapsedTime"]);
            Do();
            timer.Enabled = true;
        }

        static void Do()
        {
            
            List<string> orderList = DBHelper.GetVipUseOrderList();//VipUse里的未处理订单
            Dictionary<string,WxResult> wxOrderList = new Dictionary<string, WxResult>();//微信成功支付的订单(从orderList里筛选得出)
            foreach(string item in orderList)
            {
                WxResult result = OrderQuery.Run(item,null);
                if (result.IsWxOrder)
                {
                    if (result.IsSuccess)
                        wxOrderList.Add(item, result);
                    else
                        Console.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "->微信商户订单号:" + item + "->" + result.Error);
                }
                else//不是微信支付订单,就是支付宝支付订单
                {
                    result = OrderQuery.Run(item);
                    if (result.IsSuccess)
                        wxOrderList.Add(item, result);
                    else
                        Console.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "->支付宝商户订单号:" + item + "->" + result.Error);
                }     
            }
            if (wxOrderList.Count == 0)
            {
                Console.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss->没有要处理的订单"));
                return;
            }
            bool flag = DBHelper.UpdateVipUse(wxOrderList);//微信或支付宝订单里查询出的订单进行业务更新
            if (flag)
                foreach (KeyValuePair<string, WxResult> item in wxOrderList)
                    Console.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "->"+(item.Value.IsWxOrder?"微信":"支付宝")+"商户订单号:" + item.Key + "->处理成功");
        }

        static void DeploymentTest()
        {
            ApplicationDeployment de = ApplicationDeployment.CurrentDeployment;
            InPlaceHostingManager manager = new InPlaceHostingManager(new Uri(""));
            
        }
    }
}
