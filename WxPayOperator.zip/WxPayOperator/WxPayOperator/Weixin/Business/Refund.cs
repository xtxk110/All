﻿using System;
using System.Collections.Generic;
using System.Web;

namespace WxPayAPI
{
    /// <summary>
    /// 微信退款类
    /// </summary>
    public class Refund
    {
        /// <summary>
        /// 返回微信退款结果
        /// </summary>
        /// <param name="data">WxPayData</param>
        /// <returns></returns>
        public  WxPayData Run(WxPayData data)
        {
            if (!data.IsSet("transaction_id") && !data.IsSet("out_trade_no"))
                throw new Exception("缺少微信订单号或商户订单号");
            if (!data.IsSet("out_refund_no"))
                throw new Exception("缺少退款流水号");
            if (!data.IsSet("total_fee"))
                throw new Exception("缺少订单总金额");
            if (!data.IsSet("refund_fee"))
                throw new Exception("缺少退款金额");

            WxPayData result = WxPayApi.Refund(data);//提交退款申请给API，接收返回数据
            return result;
        }
    }
}