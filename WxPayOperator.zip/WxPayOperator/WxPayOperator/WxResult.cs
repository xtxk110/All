﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WxPayOperator
{
    public class WxResult
    {
        /// <summary>
        /// 是否有微信支付订单
        /// </summary>
        public bool IsSuccess { get; set; }
        /// <summary>
        /// 商户订单号
        /// </summary>
        public string OrderNo { get; set; }
        /// <summary>
        /// 微信支付订单ID
        /// </summary>
        public string WxPayId { get; set; }
        /// <summary>
        /// 返回的金额(元)
        /// </summary>
        public decimal Amount { get; set; }
        /// <summary>
        /// 未查询到微信订单的提示
        /// </summary>
        public string Error { get; set; }
        /// <summary>
        /// 支付方式,微信:023004;支付宝:023002
        /// </summary>
        public string PayOption { get; set; }
        /// <summary>
        /// 是否是微信订单
        /// </summary>
        public bool IsWxOrder { get; set; }
    }
}
