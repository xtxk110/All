﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Aop.Api;
using Aop.Api.Request;
using Aop.Api.Response;

namespace Com.Alipay
{
    public class AlipayHelper
    {
       /// <summary>
       /// 支付宝交易查询
       /// </summary>
       /// <param name="outTradeNo">商户订单号</param>
       /// <returns></returns>
        public AlipayTradeQueryResponse AlipayQuery(string outTradeNo)
        {
            IAopClient client = new DefaultAopClient("https://openapi.alipay.com/gateway.do", Com.Alipay.Config.APP_ID, Com.Alipay.Config.Private_key, "json", "1.0", "RSA", Com.Alipay.Config.Public_key_new, "UTF-8", false);
            AlipayTradeQueryRequest request = new AlipayTradeQueryRequest();
            request.BizContent = "{" +
            "\"out_trade_no\":\""+outTradeNo+"\"" +
            "}";
            AlipayTradeQueryResponse response = client.Execute(request);
            return response;
        }
    }
}
