﻿using System;
using System.Collections.Generic;
using System.Web;
using WxPayAPI;
using Aop.Api.Response;
using Com.Alipay;

namespace WxPayOperator
{
    public class OrderQuery
    {
        /// <summary>
        /// 根据微信订单号或商户订单号查询微信订单
        /// </summary>
        /// <param name="out_trade_no">商户订单号</param>
        /// <param name="transaction_id">微信订单号</param>
        /// <returns></returns>
        public static WxResult Run(string out_trade_no,string transaction_id)
        {
            WxResult wxResult = new WxResult { IsSuccess=false,IsWxOrder=true,PayOption= "023004" };
            WxPayData data = new WxPayData();
            if(!string.IsNullOrEmpty(transaction_id))//如果微信订单号存在，则以微信订单号为准
            {
                data.SetValue("transaction_id", transaction_id);
            }
            else//微信订单号不存在，才根据商户订单号去查单
            {
                data.SetValue("out_trade_no", out_trade_no);
            }

            WxPayData result = WxPayApi.OrderQuery(data);//提交订单查询请求给API，接收返回数据
            if (result.GetValue("return_code") as string=="SUCCESS")
            {
                if(result.GetValue("result_code") as string == "SUCCESS")
                {
                    if(result.GetValue("trade_state") as string == "SUCCESS"|| result.GetValue("trade_state") as string == "REFUND")//
                    {
                        wxResult.IsSuccess = true;
                        wxResult.OrderNo = result.GetValue("out_trade_no") as string;
                        wxResult.WxPayId = result.GetValue("transaction_id") as string;
                        wxResult.Amount = (decimal.Parse(result.GetValue("total_fee") as string)/100);
                    }
                    else
                        wxResult.Error = result.GetValue("trade_state") as string;
                }
                else
                {
                    if (result.GetValue("err_code") as string == "ORDERNOTEXIST")
                        wxResult.IsWxOrder = false;
                    wxResult.Error = result.GetValue("err_code_des") as string;
                }    
            }
            else
                wxResult.Error = result.GetValue("return_msg") as string;

            return wxResult;
        }
        /// <summary>
        /// 根据支付宝商户订单号查询支付宝订单状态
        /// </summary>
        /// <param name="out_trade_no">支付宝商户订单号</param>
        /// <returns></returns>
        public static WxResult Run(string out_trade_no)
        {
            WxResult wxResult = new WxResult { IsSuccess = false, IsWxOrder = false, PayOption = "023002" };
            AlipayTradeQueryResponse response = new AlipayHelper().AlipayQuery(out_trade_no);
            if(response.Code== "10000")
            {
                wxResult.IsSuccess = true;
                wxResult.OrderNo = response.OutTradeNo;
                wxResult.WxPayId = response.TradeNo;
                wxResult.Amount = decimal.Parse(response.TotalAmount);
            }
            else
                wxResult.Error = response.SubMsg;
            return wxResult;
        }
    }
    
}