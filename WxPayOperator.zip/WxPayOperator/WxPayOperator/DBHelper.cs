﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;

namespace WxPayOperator
{
    public class DBHelper
    {
        

        private static SqlConnection sqlServerCon = null;
        private static string conStr=ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        private static IDbConnection GetConnection()
        {
            try
            {
                sqlServerCon = new SqlConnection(conStr);
                sqlServerCon.Open();

                return sqlServerCon;
            }
            catch (Exception ex)
            {

                Console.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss->")+ ex.Message);
                return sqlServerCon;
            }

        }
        
        
        /// <summary>
        /// 获取未处理的VipUse订单,返回OrderNo集合
        /// </summary>
        /// <returns></returns>
        public static List<string> GetVipUseOrderList()
        {
            List<string> result = null;
            try
            {
                string masterType = ConfigurationManager.AppSettings["masterType"];
                string day = ConfigurationManager.AppSettings["quertyDay"];//处理时间段,0 当天,1前一天,2前两天,以此类推
                string start = DateTime.Now.ToString("yyyy-MM-dd 00:00:00");
                if (!string.IsNullOrEmpty(day) && day != "0")
                    start = DateTime.Now.AddDays(Double.Parse("-" + day)).ToString("yyyy-MM-dd 00:00:00");
                List<string> list = new List<string>();
                if (!string.IsNullOrEmpty(masterType))
                {
                    string[] temp = masterType.Split(',');
                    foreach (string item in temp)
                        list.Add(item);
                }

                
                string sql = " SELECT OrderNo FROM VipUse WHERE PayState='024001' AND MasterType IN @masterTypeList AND CreateDate >=@start ";
                using (var con = GetConnection())
                {
                    if (con != null)
                    {
                        result = con.Query<string>(sql, new { start = start,masterTypeList=list }).ToList();
                    }
                }

            }catch(Exception e) { Console.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss->") + e.Message);result = new List<string>(); }
            return result;
        }

        public static bool UpdateVipUse(Dictionary<string,WxResult> dic)
        {
            bool result = true;
            int row = 0;
            try
            {
                using (var con = GetConnection())
                {
                    
                    if (con != null)
                    {
                        IDbTransaction tran = con.BeginTransaction();
                        foreach(KeyValuePair<string,WxResult> item in dic)
                        {
                            CommandDefinition cmd = new CommandDefinition("sp_SaveVipUsePay", commandType: CommandType.StoredProcedure);
                            DynamicParameters parameters = new DynamicParameters();
                            parameters.Add("@id", null, DbType.String);
                            parameters.Add("@orderNo", item.Key, DbType.String);
                            parameters.Add("@amount", item.Value.Amount, DbType.Decimal);
                            parameters.Add("@payOption", item.Value.PayOption, DbType.String);
                            parameters.Add("@payPassword", null, DbType.String);
                            parameters.Add("@payId", item.Value.WxPayId, DbType.String);
                            parameters.Add("@payState", "024002", DbType.String); 
                            parameters.Add("@payRemark", null, DbType.String);
                            parameters.Add("@message", null, DbType.String,ParameterDirection.Output,100);

                            row += con.Execute("sp_SaveVipUsePay", parameters, tran, null, CommandType.StoredProcedure);
                        }
                        tran.Commit();
                        Console.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss->成功处理:" + dic.Count));
                    }
                }
            }
            catch (Exception e) { Console.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss->") + e.Message); result =false; }
            return result;
        }
    }
   
}
