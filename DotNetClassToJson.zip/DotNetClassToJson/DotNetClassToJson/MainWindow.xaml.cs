﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.CSharp;
using Microsoft.Win32;
using System.IO;
using System.Reflection;
using Newtonsoft.Json;
using System.Text.RegularExpressions;
using System.Runtime.Serialization;

namespace DotNetClassToJson
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        Stream file = null;
        AppDomain subDomain = null;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.CheckFileExists = true;
            ofd.CheckPathExists = true;
            ofd.Multiselect = false;
            ofd.Filter = "c#模型文件|*.cs";
            ofd.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            ofd.Title = "C#模型文件选择框";
            bool flag = (bool)ofd.ShowDialog();
            if (flag)
            {
                this.path_textblock.Text = ofd.FileName;
                file = ofd.OpenFile();
                using(StreamReader sr=new StreamReader(file))
                {
                    this.source_textbox.Text = sr.ReadToEnd();
                }
                file.Close();
                file = null;
            }
                
        }

        private void Button_Click_1(object sender, RoutedEventArgs e) 
        {
            if(string.IsNullOrEmpty(this.source_textbox.Text))
            {
                MessageBox.Show("待转换内容为空");
                return;
            }
            AppDomainSetup ads = new AppDomainSetup();
            ads.ApplicationBase = AppDomain.CurrentDomain.BaseDirectory;
            ads.ApplicationName = "sub";
            ads.ShadowCopyDirectories = ads.ApplicationBase;
            ads.CachePath = ads.ApplicationBase;
            ads.ShadowCopyFiles = "true";
            ads.ConfigurationFile = AppDomain.CurrentDomain.SetupInformation.ConfigurationFile;
            subDomain = AppDomain.CreateDomain("sub", AppDomain.CurrentDomain.Evidence, ads);
            Proxy proxy= (Proxy)subDomain.CreateInstanceAndUnwrap(Assembly.GetExecutingAssembly().FullName, typeof(Proxy).FullName);
            string nameSpace = string.Empty;
            Regex regex = new Regex("namespace\\s+(\\w+)\\s*{",RegexOptions.Multiline);
            if (regex.IsMatch(this.source_textbox.Text.Trim()))
            {
                Match match1 = regex.Match(this.source_textbox.Text.Trim());
                nameSpace = match1.Groups[1].Value;
            }
            Match match= Regex.Match(this.source_textbox.Text.Trim(), "class\\s+(\\w+)\\s*(:\\s*\\w+)?\\s+{", RegexOptions.Multiline);
            string className= match.Groups[1].Value;
            try
            {
                Object obj = proxy.CreateInstance(nameSpace+"."+className, this.source_textbox.Text.Trim());
                this.result_textblock.Text = JsonConvert.SerializeObject(obj, Formatting.Indented);
                obj = null;
            }
            catch(Exception ex)
            {
                AppDomain.Unload(subDomain);
                this.result_textblock.Text = ex.Message;
                return;
            }
            AppDomain.Unload(subDomain);
            
        }
    }
}
