﻿using Microsoft.CSharp;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using Newtonsoft.Json;

namespace DotNetClassToJson
{
    [Serializable]
    public class Proxy
    {
        private const BindingFlags bfi = BindingFlags.Instance | BindingFlags.Public | BindingFlags.CreateInstance;

        public object CreateInstance(string fullClassName,string resource)
        {
            Assembly assembly = GetAssembly(resource,out string error);
            if (assembly == null)
                throw new Exception(error);
            object obj = assembly.CreateInstance(fullClassName, true);
            return obj;
        }

        public Assembly GetAssembly(string resource,out string error)
        {
            Assembly assembly = new ComplierHelper().GetAssembly(resource,out error);
            return assembly;
        }
    }
    /// <summary>
    /// 动态编译C#代码,返回程序集对象
    /// </summary>
    public class ComplierHelper
    {
        CSharpCodeProvider csp;
        CompilerParameters cp;
        CompilerResults cr;
        /// <summary>
        /// 需要动态编译的C#文件
        /// </summary>
        public string CSharpFilePath { get; set; }

        public ComplierHelper()
        {
            csp = new CSharpCodeProvider();
            cp = new CompilerParameters { GenerateExecutable = false, GenerateInMemory = true };
            cp.ReferencedAssemblies.Add("System.dll");
            cp.ReferencedAssemblies.Add("System.Data.dll");
            cp.ReferencedAssemblies.Add("System.Data.DataSetExtensions.dll");
            cp.ReferencedAssemblies.Add("System.Xml.dll");
            cp.ReferencedAssemblies.Add("System.Xml.Linq.dll");
            cp.ReferencedAssemblies.Add("System.Runtime.Serialization.dll");
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="csPath">需要动态编译的C#文件路径</param>
        public ComplierHelper(string csPath) : this()
        {
            this.CSharpFilePath = csPath;
        }

        public Assembly GetAssembly(string resource,out string error)
        {
            error = string.Empty;
            if (string.IsNullOrEmpty(resource))
            {
                error = "源代码为空";
                return null;
            }
               
            cr = csp.CompileAssemblyFromSource(cp, resource);
            if (cr.Errors.Count > 0)
            {
                foreach (CompilerError item in cr.Errors)
                    error= string.Concat(error, "\r\n", item);
                return null;
            }
            return cr.CompiledAssembly;
        }
       
    }
}
