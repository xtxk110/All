﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.CSharp;
using System.CodeDom.Compiler;
using System.Reflection;

namespace Test
{
    class Program
    {
        static string exDir = AppDomain.CurrentDomain.BaseDirectory+@"Extend\";
        static void Main(string[] args)
        {
            ComplierHelper helper = new ComplierHelper(exDir + "Extend1.cs");
            Assembly assembly = helper.GetAssembly();
            Console.WriteLine(assembly.FullName);
            object instance = assembly.CreateInstance("Test.Extend1");
            instance.GetType().InvokeMember("Show", BindingFlags.InvokeMethod, null, instance, new object[] { "测试内容" });
            Console.ReadKey();
        }
    }
}
