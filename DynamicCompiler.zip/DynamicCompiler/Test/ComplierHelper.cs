﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.CSharp;
using System.CodeDom.Compiler;
using System.IO;
using System.Reflection;

namespace Test
{
    public class ComplierHelper
    {
        CSharpCodeProvider csp;
        CompilerParameters cp;
        CompilerResults cr;
        /// <summary>
        /// 需要动态编译的C#文件
        /// </summary>
        public string CSharpFilePath { get; set; }

        public ComplierHelper()
        {
            csp = new CSharpCodeProvider();
            cp = new CompilerParameters { GenerateExecutable = false, GenerateInMemory = true };
            cp.ReferencedAssemblies.Add("System.dll");
            cp.ReferencedAssemblies.Add("System.Data.dll");
            cp.ReferencedAssemblies.Add("System.Xml.dll");
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="csPath">需要动态编译的C#文件路径</param>
        public ComplierHelper(string csPath) : this()
        {
            this.CSharpFilePath = csPath;
        }

        public Assembly GetAssembly()
        {
            string resource = GetString(this.CSharpFilePath);
            if (string.IsNullOrEmpty(resource))
                return null;
            cr = csp.CompileAssemblyFromSource(cp, resource);
            if (cr.Errors.Count > 0)
            {
                foreach (CompilerError item in cr.Errors)
                    Console.WriteLine(item.ErrorText);
                return null;
            }
            return cr.CompiledAssembly;    
        }
        private string GetString(string path)
        {
            string result = string.Empty;
            try
            {
                using(StreamReader sr=new StreamReader(path))
                {
                    result = sr.ReadToEnd();
                }
            }
            catch { }
            return result;
        }
    }
}
