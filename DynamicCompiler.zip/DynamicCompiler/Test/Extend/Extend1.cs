﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Test
{
    public class Extend1
    {
        public void Show(string message)
        {
            Console.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "->" + message);
        }
    }
}
